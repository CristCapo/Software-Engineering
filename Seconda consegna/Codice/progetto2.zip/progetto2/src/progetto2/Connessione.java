package progetto2;
import java.io.File;
import java.io.IOException;


import org.neo4j.driver.v1.*;

public class Connessione {

	public Session connettiti() throws IOException{
		
		
		
		Driver driver = GraphDatabase.driver( "bolt://localhost", AuthTokens.basic("neo4j", "abc"), Config.build()
		        .withEncryptionLevel( Config.EncryptionLevel.REQUIRED )
		        .withTrustStrategy( Config.TrustStrategy.trustOnFirstUse( new File( "/path/to/neo4j_known_hosts" ) ) )
		        .toConfig() );
		
		return driver.session();
		
	}
	
	
}
