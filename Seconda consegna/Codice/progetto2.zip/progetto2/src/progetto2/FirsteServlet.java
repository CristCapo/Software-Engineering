package progetto2;



import java.io.IOException;
import java.util.Enumeration;
import java.util.LinkedList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.neo4j.driver.v1.Session;

/**
 * Servlet implementation class FirstServlet
 */
@WebServlet("/FirstServlet")
public class FirsteServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirsteServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int n=0;
		int m =0;
		int o=0;
		int k=0;
		int i=0;
		String[] elimina;
		String[] calcola;
		Enumeration<String> e = request.getParameterNames();
		Enumeration<String> e1 = request.getParameterNames();
		Enumeration<String> e2 = request.getParameterNames();
		String[] parametri_fissi = new String[5];
		LinkedList<String> parametri_nodi = new LinkedList<String>();
		LinkedList<String> parametri_archi = new LinkedList<String>();
		while (e1.hasMoreElements()){
			e1.nextElement();
			i++;
			
		}
		if (i==1) 
		{
			response.getWriter().println("elimina");
			elimina = new String[i];
			elimina[0]=request.getParameter("inserisci");
			Session session = new Connessione().connettiti();
			new Neo4j().deleteTree(elimina[0], session);
			session.close();
		}
		
		if (i==3) {
			response.getWriter().println("calcola");
			calcola = new String[i];
			while(e2.hasMoreElements())
			
			{
				String name = (String) e2.nextElement();
			    String value = request.getParameter(name);
			    calcola[k] = value;
			    k++;
			}
			
			Session session = new Connessione().connettiti();
			new Neo4j().res(session,Integer.parseInt(calcola[1]),Integer.parseInt(calcola[2]), calcola[0] );
			session.close();
			
		}
		if (i >3) {
		response.getWriter().println("crea");
		
		while (e.hasMoreElements())
		{
			String name = (String) e.nextElement();
		    String value = request.getParameter(name);
		    
		    if (name.equals("parametroNodi"+n)){
		    		parametri_nodi.add(value);
		    		response.getWriter().println(parametri_nodi.get(n));
		    		response.getWriter().println("ciao1_"+n);
		    		n++;
				
			}
		    else{
		    		if (name.equals("parametroArchi"+m)){
		    			parametri_archi.add(value);
		    			response.getWriter().println(parametri_archi.get(m));
		    			response.getWriter().println("ciao2_"+m);
		    			m++;
		    		}
		    		else {
		    			parametri_fissi[o]=value;
		    		    response.getWriter().println(parametri_fissi[o]);
		    		    response.getWriter().println("ciao3_s"+o);
		    		    o++;
		    			
		    		}
		    }		
		
		
		}
		new Albero(Integer.parseInt(parametri_fissi[2]),Integer.parseInt(parametri_fissi[1]),parametri_fissi[0],parametri_nodi,parametri_archi,Integer.parseInt(parametri_fissi[3]),Integer.parseInt(parametri_fissi[4]));

		}
		
	}
}