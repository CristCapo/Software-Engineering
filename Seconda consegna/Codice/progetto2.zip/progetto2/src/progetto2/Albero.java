package progetto2;
import java.io.IOException;
import java.util.LinkedList;
import java.util.Random;
import java.util.TreeMap;

import org.neo4j.driver.v1.Session;

public class Albero {

	private int Depth;
	private int SplitSize;
	private String idAlbero;
	
	public Albero(int depth,int SplitSize, String idAlbero, LinkedList<String> attrNode, LinkedList<String> attrEdge, int N, int K) throws IOException{
		System.out.println(System.currentTimeMillis());
		this.Depth=depth;
		this.SplitSize=SplitSize;
		this.idAlbero = idAlbero;
		
		TreeMap<Integer,LinkedList<Integer>> nodi = this.creaNodi(this.SplitSize, this.Depth, attrNode, K, N);
		
		this.creaArchi(nodi, attrEdge, K, N);
		Session sess = new Connessione().connettiti();
		Neo4j create = new Neo4j();
		create.createNodi(sess, this.idAlbero);
		create.createArchi(sess, this.idAlbero);
		System.out.println(System.currentTimeMillis());
		System.out.println("Albero " + this.idAlbero + " creato con successo");
		sess.close();
	}
	
	public TreeMap<Integer,LinkedList<Integer>> creaNodi(int SplitSize, int Depth, LinkedList<String> attrNode, int K, int N) throws IOException{
		
		CreaCSV csv = new CreaCSV();
		TreeMap<Integer,LinkedList<Integer>> archi = csv.csvNodi(this.idAlbero, SplitSize, Depth, attrNode, K, N);
		return archi;
		
	}
	
	public boolean creaArchi(TreeMap<Integer,LinkedList<Integer>> nodi, LinkedList<String> attrEdge, int K, int N) throws IOException{
		
		CreaCSV csv = new CreaCSV();
		
		boolean creato = csv.csvArchi(this.idAlbero, nodi, attrEdge, K, N);
		
		return creato;
		
		
	}
	
}
