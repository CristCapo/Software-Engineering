package progetto2;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.neo4j.driver.internal.InternalStatementResult;
import org.neo4j.driver.v1.*;

public class Neo4j {

	public void createNodi(Session session,String IDAlbero) throws FileNotFoundException, IOException{
		
		System.out.println(System.currentTimeMillis());
		
		
		
		String file="C:\\Users\\Cristian\\Documents\\Neo4j\\default.graphdb\\Import\\nodiCsv" +IDAlbero +".csv";
		
		FileReader reader = new FileReader(file);
		
		BufferedReader br = new BufferedReader(reader);
		
		String split =",";
		
		String line = br.readLine();

		String[] res = line.split(split);
		
		List<String> x = Arrays.asList(res);
		
		Iterator<String> it = x.iterator();
		
		String a = it.next();
		
		String b = "CREATE (:Vertex {" + a +":" + " toString(line." + a +")";
		
		while(it.hasNext()){
			String c = it.next();
			b+="," + c + ":" + " toFloat(line." + c + ")";
		}
		
		b+="}" + ")";
		
		StatementResult result = session.run( "USING PERIODIC COMMIT LOAD CSV WITH HEADERS FROM 'file:///nodiCsv" + IDAlbero + ".csv' as line "
				+ b + " RETURN 1 as res");
		
		
		Record p = result.next();
		Value k = p.get("res");
		while (k.asInt() != 1){
			
		}
		br.close();
		
		
		
		System.out.println("Nodi Importati con successo");
		System.out.println(System.currentTimeMillis());
	}
	
	public void createArchi(Session session,String IDAlbero) throws IOException{
		System.out.println(System.currentTimeMillis());
		String file="C:\\Users\\Cristian\\Documents\\Neo4j\\default.graphdb\\Import\\archiCsv" + IDAlbero+".csv";
		
		FileReader reader = new FileReader(file);
		
		BufferedReader br = new BufferedReader(reader);
		
		String split =",";
		
		String line = br.readLine();

		String[] res = line.split(split);
		
		List<String> x = Arrays.asList(res);
		
		System.out.println(x);
		
		Iterator<String> it = x.iterator();
		
		String a = x.get(0);
		
		String b = " CREATE (N) - [:Padre {" + a +": " + "toString(line." + a +")";
		
		String d="";
		
		for(int i=1 ; i<x.size();i++){
			
			String c = x.get(i);
			System.out.println(c);
			if (c.equals("StartVertex")){
				
				i++;
				c=x.get(i);
			}
			System.out.println(c);
			if(c.equals("EndVertex")){
				
				i++;
				d=c;
				c=x.get(i);
			}
			System.out.println(d);
			b+=", " + c +":" + " toFloat(line." + c + ")" ;
		}
		
		b += "}]";
		
		
		String z = "USING PERIODIC COMMIT LOAD CSV WITH HEADERS FROM 'file:///archiCsv" + IDAlbero + ".csv' as line "
				+ "MATCH (N:Vertex {IDAlbero: toString(line.IDAlbero), ID: toFloat(line.StartVertex)}), (M:Vertex {IDAlbero: toString(line.IDAlbero) , ID: toFloat(line.EndVertex)}) "
				+ b + " ->" + " (M) RETURN 1 AS res";
		
		
		
		StatementResult result = session.run(z);
		Record p = result.next();
		Value k = p.get("res");
		while (k.asInt() != 1){
			
		}
		br.close();
		System.out.println("Archi creati con successo");
		System.out.println(System.currentTimeMillis());
	}
	
	public void res(Session session,int x,int y,String IDAlbero){
		
		
		
		System.out.println(System.currentTimeMillis());
		String attrnode = this.takeattrnode(session,IDAlbero);
		String attredge = this.takeattredge(session,IDAlbero);
		
		StatementResult resnode = session.run("MATCH path = (N:Vertex {IDAlbero: '" + IDAlbero + "', ID: " + x +" }) - [*] -> (M:Vertex {IDAlbero: '" + IDAlbero + "' ,ID: " + y +"}) RETURN " 
				+ attredge   
				+ attrnode);
		
		Record record = resnode.next();
		for(String key : record.keys()){
			System.out.println(key + ": " + record.get(key));
		}
		
		System.out.println(System.currentTimeMillis());
		
	}
	
	public String takeattrnode(Session session,String IDAlbero){
		
		StatementResult resnode = session.run("MATCH (N:Vertex {IDAlbero: '" + IDAlbero + "', ID: 0}) RETURN PROPERTIES(N)");
		Record record = resnode.next();
		String attrnode = "";
		
		for(String a : record.get("PROPERTIES(N)").keys()){
			
			if( a.equals("ID") || a.equals("IDAlbero")){
				
				continue;
				
			}
			
			attrnode +=" ,reduce(total = 0, N in nodes(path) | total + ";
			attrnode += "N." + a + ") as Node_" + a;
			
		}

		System.out.println(attrnode);
		return attrnode;
		
	}
	
	public String takeattredge(Session session,String IDAlbero){
		
		StatementResult resedge = session.run("MATCH () - [R:Padre {IDAlbero: '" + IDAlbero + "', ID: 1}] -> () RETURN PROPERTIES(R)");
		Record record = resedge.next();
		String attredge = "";
		boolean primo = true;
		for(String a : record.get("PROPERTIES(R)").keys()){
			
			if( a.equals("ID") || a.equals("IDAlbero")){
				
				continue;
				
			}
			if (primo)
				primo = false;
				
			
			
			else
				attredge += ",";
			
			
			attredge += " reduce( total = 0, R in relationships(path) | total + ";
			attredge += " R." + a + " ) as Edge_" + a;

		}
		
		System.out.println(attredge);
		return attredge;
		
	}
	
	public void deleteTree(String idAlbero, Session session){
		System.out.println(System.currentTimeMillis());
		StatementResult del = session.run("MATCH (N:Vertex {IDAlbero: '" + idAlbero + "'}) WITH N LIMIT 1000 DETACH DELETE N RETURN 1 as res");
		if(del.hasNext()){
		
		Record p = del.next();
		Value k = p.get("res");
		while (k.asInt() == 1){
			del = session.run("MATCH (N:Vertex {IDAlbero: '" + idAlbero + "'}) WITH N LIMIT 1000 DETACH DELETE N RETURN 1 as res");
			if (!del.hasNext())
				break;
			k = p.get("res");
		}
	}
		System.out.println(System.currentTimeMillis());
		System.out.println("Albero "+ idAlbero + " eliminato con successo");
	}
	

}
